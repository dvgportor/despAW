@extends('plantillas.master')

@section('title')

@stop

@section('central')
<h2>Email Enviado</h2>


- El administrador debe aceptar su solicitud para registrarse con privilegios.


