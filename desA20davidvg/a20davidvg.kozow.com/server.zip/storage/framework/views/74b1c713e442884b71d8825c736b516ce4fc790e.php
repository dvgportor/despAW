

<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('central'); ?>
<h2>Email Enviado</h2>


- El administrador debe aceptar su solicitud para registrarse con privilegios.



<?php echo $__env->make('plantillas.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dominio.local\proyectoFDC\resources\views/mail/mail.blade.php ENDPATH**/ ?>