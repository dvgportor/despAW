

<?php $__env->startSection('central'); ?>

<h2>EDICIÓN DE ARCHIVO</h2>

<div class="container">
    <form action="<?php echo e(route('archivos.update', $id)); ?>" method="post" id = "myForm" enctype="multipart/form-data"> 
        
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
      
        
<?php echo $__env->make('archivos.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dominio.local\proyectoFDC\resources\views/archivos/edit.blade.php ENDPATH**/ ?>