



<?php $__env->startSection('central'); ?>

<h2>CREACIÓN DE CLIENTE</h2>

<div class="container md-3">
    <form action="<?php echo e(route('clientes.store')); ?>" method="post"> 
        <?php echo csrf_field(); ?>
<?php echo $__env->make('clientes.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\a20davidvg.local\resources\views/clientes/create.blade.php ENDPATH**/ ?>