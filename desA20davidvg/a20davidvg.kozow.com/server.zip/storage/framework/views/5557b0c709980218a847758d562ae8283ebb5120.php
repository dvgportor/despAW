

 <div class="row mb-3">
    <label class="col-md-4 col-form-label text-md-end"for="nombre">Titulo:</label>
    <div class="col-md-6">
    <input type="text" class="form-control" name="titulo" id="titulo">
    <?php $__errorArgs = ["titulo"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
 </div>
 <div class="row mb-3">
        <label class =" col-md-4 col-form-label text-md-end"for="exampleFormControlTextarea1">Descripción</label>
        <div class="col-md-6">
        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" form="myForm" name="descripcion"></textarea>
      
 
    <?php $__errorArgs = ["descripcion"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
 </div>
 </div>
    <div class="row mb-3">
        <label class="col-md-4 col-form-label text-md-end" for="enlace">Enlace:</label>
        <div class="col-md-6">
        <input type="file" class="form-control" name="enlace" id="enlace">
        <?php $__errorArgs = ["enlace"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>    
    </div>



    </div>
   <center> <input type="submit" class= "btn btn-success" name="enviar"></center>
    
    
    <?php /**PATH C:\laragon\www\a20davidvg.local\resources\views/archivos/form.blade.php ENDPATH**/ ?>