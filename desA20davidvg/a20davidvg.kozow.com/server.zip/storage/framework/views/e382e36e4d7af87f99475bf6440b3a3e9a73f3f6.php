

<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('central'); ?>
<h2>LISTADO DE USUARIOS</h2>
<table class="table">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Usuario</th>
            <th scope="col">Nombre</th>
            <th scope="col">Apellidos</th>
            <th scope="col">Email</th>
            <th scope="col">Teléfono</th>
            
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($cliente->id); ?></th>
            <th scope="row"><?php echo e($cliente->usuario); ?></th>
            <th scope="row"><?php echo e($cliente->nombre); ?></th>
            <th scope="row"><?php echo e($cliente->apellidos); ?></th>
            <th scope="row"><?php echo e($cliente->email); ?></th>
            <th scope="row"><?php echo e($cliente->telefono); ?></th>
            <th scope="row"><a href="<?php echo e(route('clientes.edit',$cliente)); ?>" class="btn btn-primary">Editar</a>
            <form action="<?php echo e(route('clientes.destroy',$cliente)); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> <input type="submit" class="btn btn-danger" value="Borrar" /></form> <a href="<?php echo e(route('archivos.show', $cliente )); ?>" class="btn btn-secondary">Archivos</a>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantillas.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dominio.local\proyectoFDC\resources\views/clientes/index.blade.php ENDPATH**/ ?>