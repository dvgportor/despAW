



<?php $__env->startSection('central'); ?>

<h2>EDICIÓN DE USUARIO</h2>

<div class="container">
    <form action="<?php echo e(route('users.update',$user->id)); ?>" method="post"> 
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
<?php echo $__env->make('users.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dominio.local\proyectoFDC\resources\views/users/edit.blade.php ENDPATH**/ ?>