

<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('central'); ?>
<h2>LISTADO DE USUARIOS</h2>
<table class="table">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Usuario</th>
            <th scope="col">Nombre</th>
            <th scope="col">Apellidos</th>
            <th scope="col">Email</th>
            <th scope="col">Teléfono</th>
            
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($user->id); ?></th>
            <th scope="row"><?php echo e($user->usuario); ?></th>
            <th scope="row"><?php echo e($user->nombre); ?></th>
            <th scope="row"><?php echo e($user->apellidos); ?></th>
            <th scope="row"><?php echo e($user->email); ?></th>
            <th scope="row"><?php echo e($user->telefono); ?></th>
            <th scope="row"><a href="<?php echo e(route('users.edit',$user)); ?>" class="btn btn-primary">Editar</a>
            <form action="<?php echo e(route('users.destroy',$user)); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> <input type="submit" class="btn btn-danger" value="Borrar" /></form> <a href="<?php echo e(route('archivos.show', $user )); ?>" class="btn btn-secondary">Archivos</a>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo $users->links(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantillas.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\a20davidvg.local\resources\views/users/index.blade.php ENDPATH**/ ?>