



<?php $__env->startSection('central'); ?>

<center><h2>EDICIÓN DE CLIENTE</h2></center>

<div class="container ">
    <form action="<?php echo e(route('clientes.update',$cliente->id)); ?>" method="post"> 
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
<?php echo $__env->make('clientes.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\a20davidvg.local\resources\views/clientes/edit.blade.php ENDPATH**/ ?>