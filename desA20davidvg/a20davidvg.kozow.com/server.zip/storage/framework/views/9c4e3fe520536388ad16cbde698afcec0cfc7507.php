



<?php $__env->startSection('central'); ?>

<h2>CREACIÓN DE ARCHIVO</h2>

<div class="container">
    <form action="<?php echo e(route('archivos.store')); ?>"  method="post" id="myForm" enctype="multipart/form-data"> 
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="cliente_id">ID Usuario:</label>
            <select name="cliente_id" id="cliente_id">
                <option value="<?php echo e($user_id); ?>" selected="true"><?php echo e($user_id); ?></option>
            </select>
<?php echo $__env->make('archivos.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dominio.local\proyectoFDC\resources\views/archivos/create.blade.php ENDPATH**/ ?>