
    <div class="form-group">
    <label for="nombre">Titulo:</label>
    <input type="text" name="titulo" id="titulo">
    <?php $__errorArgs = ["titulo"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <label for="exampleFormControlTextarea1">Descripción</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" form="myForm" name="descripcion"></textarea>
      </div>
    <?php $__errorArgs = ["descripcion"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="form-group">
        <label for="enlace">Enlace:</label>
        <input type="file" name="enlace" id="enlace">
        <?php $__errorArgs = ["enlace"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>    



    </div>
    <input type="submit" name="enviar">
    </div>
    
    
    </form>
    <?php /**PATH C:\xampp\htdocs\dominio.local\proyectoFDC\resources\views/archivos/form.blade.php ENDPATH**/ ?>