



<?php $__env->startSection('central'); ?>
<h2>LISTADO DE ARCHIVOS</h2>

<table class="table">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">UserID</th>
            <th scope="col">Titulo</th>
            <th scope="col">Enlace</th>
            <th scope="col">Descripción</th>
            <th scope="col">Fecha Creación</th>
            
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($archivo->id); ?></th>
            <th scope="row"><?php echo e($archivo->cliente_id); ?></th>
            <th scope="row"><?php echo e($archivo->titulo); ?></th>
            <th scope="row"><?php echo e($archivo->enlace); ?></th>
            <th scope="row"><?php echo e($archivo->descripcion); ?></th>
            <th scope="row"><?php echo e($archivo->created_at); ?></th>
            <th scope="row"> <form action="<?php echo e(route('archivos.download', $archivo->enlace)); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field('POST'); ?> <button type="submit" class="btn btn-outline-primary" value="<?php echo e($archivo->enlace); ?>"><i class="fa fa-download"></i></button></form>
            </th>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dominio.local\proyectoFDC\resources\views/archivos/idInvitados.blade.php ENDPATH**/ ?>