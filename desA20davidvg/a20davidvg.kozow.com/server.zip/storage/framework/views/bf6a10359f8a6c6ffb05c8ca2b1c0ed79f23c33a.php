



<?php $__env->startSection('central'); ?>
<h2>LISTADO DE ARCHIVOS</h2><a href="<?php echo e(route('{id}.create', $id)); ?>" class="btn btn-primary">Crear <i class="fa fa-plus-square"></i></a>

<table class="table">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">UserID</th>
            <th scope="col">Titulo</th>
            <th scope="col">Enlace</th>
            <th scope="col">Descripción</th>
            <th scope="col">Fecha Creación</th>
            
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($archivo->id); ?></th>
            <th scope="row"><?php echo e($archivo->cliente_id); ?></th>
            <th scope="row"><?php echo e($archivo->titulo); ?></th>
            <th scope="row"><?php echo e($archivo->enlace); ?></th>
            <th scope="row"><?php echo e($archivo->descripcion); ?></th>
            <th scope="row"><?php echo e($archivo->created_at); ?></th>
            <th scope="row"><a href="<?php echo e(route('archivos.edit', $archivo->id)); ?>" class="btn btn-outline-success">Editar</a>
         <form action="<?php echo e(route('archivos.destroy', $archivo->id)); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> <input type="submit" class=" btn btn-outline-danger" value="Borrar" /></form> <form action="<?php echo e(route('archivos.download', $archivo->enlace)); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field('POST'); ?> <button type="submit" class="btn btn-outline-primary" value="<?php echo e($archivo->enlace); ?>"><i class="fa fa-download"></i></button></form>
            </th>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\a20davidvg.local\resources\views/archivos/id.blade.php ENDPATH**/ ?>