



<?php $__env->startSection('central'); ?>

<center><h2>CREACIÓN DE ARCHIVO</h2></center>

<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">CREACIÓN</div>



    <form action="<?php echo e(route('archivos.store')); ?>"  method="post" id="myForm" enctype="multipart/form-data"> 
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
        
            <center><label for="cliente_id">ID Usuario:</label></center>
            <div class="row mb-6">
            <select class= "form-select" name="cliente_id" id="cliente_id">
                <option value="<?php echo e($user_id); ?>" selected="true"><?php echo e($user_id); ?></option>
            </select>
        </div>
        </div>
        
<?php echo $__env->make('archivos.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\a20davidvg.local\resources\views/archivos/create.blade.php ENDPATH**/ ?>